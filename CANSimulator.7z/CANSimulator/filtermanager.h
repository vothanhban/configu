#ifndef FILTERMANAGER_H
#define FILTERMANAGER_H

#include <QMainWindow>
#include "measuresetup.h"
#include "ui_filtermanager.h"


class FilterManagerWindow : public  QMainWindow, Ui_FilterManager
{
    Q_OBJECT

public:
    explicit FilterManagerWindow(QWidget *parent = 0);
    ~FilterManagerWindow();

private:

};

class FilterNodeManager{

};

#endif // FILTERMANAGER_H
