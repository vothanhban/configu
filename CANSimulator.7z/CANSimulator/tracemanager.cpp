#include "tracemanager.h"
#include "ui_tracemanager.h"

TraceManager::TraceManager(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::TraceManager)
{
    ui->setupUi(this);
}

TraceManager::~TraceManager()
{
    delete ui;
}
