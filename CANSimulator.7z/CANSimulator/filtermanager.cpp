#include "filtermanager.h"
#include "ui_filtermanager.h"

FilterManagerWindow::FilterManagerWindow(QWidget *parent) :
    QMainWindow(parent)
{
    setupUi(this);
}

FilterManagerWindow::~FilterManagerWindow()
{
}
